package com.example.cast

import com.example.data.model.ChannelType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CastUrlPolicyTest {

    @Test fun redactsXtreamPathCredentials() {
        val r = CastUrlPolicy.redact("http://srv.example:8080/live/myuser/mypass/123.ts")
        assertEquals("http://srv.example:8080/live/***/***/123.ts", r)
        assertFalse(r.contains("myuser")); assertFalse(r.contains("mypass"))
    }

    @Test fun redactsMovieAndSeriesPaths() {
        assertEquals("http://h/movie/***/***/9.mkv", CastUrlPolicy.redact("http://h/movie/u/p/9.mkv"))
        assertEquals("http://h/series/***/***/9.mp4", CastUrlPolicy.redact("http://h/series/u/p/9.mp4"))
    }

    @Test fun redactsQueryAndUserInfo() {
        assertEquals("http://h/get.php?username=***&password=***&type=m3u",
            CastUrlPolicy.redact("http://h/get.php?username=bob&password=secret&type=m3u"))
        assertEquals("http://***@h/x.m3u8", CastUrlPolicy.redact("http://bob:secret@h/x.m3u8"))
    }

    @Test fun plainUrlHasNoCredentials() {
        assertFalse(CastUrlPolicy.hasCredentials("https://cdn.example.com/stream/index.m3u8"))
        assertTrue(CastUrlPolicy.hasCredentials("http://h/live/u/p/1.m3u8"))
    }

    @Test fun liveTsBecomesHlsOnlyForXtreamLive() {
        assertEquals("http://h/live/u/p/1.m3u8", CastUrlPolicy.toCastableUrl("http://h/live/u/p/1.ts", ChannelType.LIVE))
        assertEquals("http://h/live/u/p/1.mp4", CastUrlPolicy.toCastableUrl("http://h/live/u/p/1.mp4", ChannelType.LIVE))
        assertEquals("http://h/movie/u/p/1.ts", CastUrlPolicy.toCastableUrl("http://h/movie/u/p/1.ts", ChannelType.MOVIE))
        assertEquals("http://h/a/b.ts", CastUrlPolicy.toCastableUrl("http://h/a/b.ts", ChannelType.LIVE))
    }

    @Test fun mimeTypes() {
        assertEquals("application/x-mpegURL", CastUrlPolicy.mimeType("http://h/a.m3u8?x=1", ChannelType.LIVE))
        assertEquals("video/mp4", CastUrlPolicy.mimeType("http://h/a.mp4", ChannelType.MOVIE))
        assertEquals("video/x-matroska", CastUrlPolicy.mimeType("http://h/a.mkv", ChannelType.MOVIE))
        assertEquals("application/x-mpegURL", CastUrlPolicy.mimeType("http://h/stream", ChannelType.LIVE))
        assertEquals("video/mp4", CastUrlPolicy.mimeType("http://h/stream", ChannelType.MOVIE))
    }

    @Test fun loopbackDetection() {
        assertTrue(CastUrlPolicy.isLoopbackHost("http://localhost:8080/a"))
        assertTrue(CastUrlPolicy.isLoopbackHost("http://127.0.0.1/a"))
        assertFalse(CastUrlPolicy.isLoopbackHost("http://192.168.1.10/a"))
    }
}
