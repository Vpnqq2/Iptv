package com.example.cast

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class CastRelayServerTest {
    private lateinit var upstream: MockWebServer
    private lateinit var relay: CastRelayServer
    private val client = OkHttpClient()

    @Before fun setUp() {
        upstream = MockWebServer().also { it.start() }
        relay = CastRelayServer()
        relay.start()
        relay.currentHost = "127.0.0.1"
    }

    @After fun tearDown() { relay.stop(); upstream.shutdown() }

    private fun get(url: String, range: String? = null) =
        client.newCall(Request.Builder().url(url).apply { range?.let { header("Range", it) } }.build()).execute()

    @Test fun relaysBytesWithCorsAndNeverExposesUpstream() {
        upstream.enqueue(MockResponse().setBody("hello-video").setHeader("Content-Type", "video/mp4"))
        val url = relay.urlFor("127.0.0.1", upstream.url("/movie/user/secret/1.mp4").toString())
        assertFalse(url.contains("secret")); assertFalse(url.contains("user"))
        get(url).use { r ->
            assertEquals(200, r.code)
            assertEquals("*", r.header("Access-Control-Allow-Origin"))
            assertEquals("hello-video", r.body!!.string())
        }
    }

    @Test fun forwardsRangeRequests() {
        upstream.enqueue(MockResponse().setResponseCode(206).setBody("ell").setHeader("Content-Range", "bytes 1-3/11"))
        val url = relay.urlFor("127.0.0.1", upstream.url("/a.mp4").toString())
        get(url, "bytes=1-3").use { r ->
            assertEquals(206, r.code)
            assertEquals("bytes 1-3/11", r.header("Content-Range"))
        }
        assertEquals("bytes=1-3", upstream.takeRequest().getHeader("Range"))
    }

    @Test fun rewritesHlsPlaylistSoSegmentsGoThroughRelay() {
        upstream.enqueue(MockResponse().setHeader("Content-Type", "application/vnd.apple.mpegurl")
            .setBody("#EXTM3U\n#EXTINF:6,\nseg1.ts\n"))
        val url = relay.urlFor("127.0.0.1", upstream.url("/live/u/p/1.m3u8").toString())
        get(url).use { r ->
            val body = r.body!!.string()
            assertTrue(body.startsWith("#EXTM3U"))
            assertTrue(body.contains("http://127.0.0.1:${relay.port}/r/"))
            assertFalse(body.contains(upstream.hostName + ":" + upstream.port))
        }
    }

    @Test fun unknownIdIs404() {
        get("http://127.0.0.1:${relay.port}/r/${"0".repeat(32)}").use { assertEquals(404, it.code) }
        get("http://127.0.0.1:${relay.port}/other").use { assertEquals(404, it.code) }
    }

    @Test fun upstreamAuthFailureIsPassedAsStatusWithoutBody() {
        upstream.enqueue(MockResponse().setResponseCode(403).setBody("user=secret"))
        val url = relay.urlFor("127.0.0.1", upstream.url("/live/u/p/1.ts").toString())
        get(url).use { r ->
            assertEquals(403, r.code)
            assertEquals("", r.body!!.string())
        }
    }

    @Test fun unreachableUpstreamIs502() {
        val dead = upstream.url("/x.mp4").toString()
        upstream.shutdown()
        val url = relay.urlFor("127.0.0.1", dead)
        get(url).use { assertEquals(502, it.code) }
    }
}
