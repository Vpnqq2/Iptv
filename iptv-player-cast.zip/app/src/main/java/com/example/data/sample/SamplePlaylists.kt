package com.example.data.sample

import com.example.data.local.EpgProgramEntity
import com.example.data.local.PlaylistEntity
import com.example.data.local.StreamEntity
import com.example.data.model.ChannelType
import com.example.data.model.PlaylistType

object SamplePlaylists {

    fun createSamplePlaylist(): PlaylistEntity {
        return PlaylistEntity(
            id = 1,
            name = "Smart IPTV World",
            type = PlaylistType.M3U_URL,
            sourceUrl = "http://iptv.server:8080/get.php",
            channelCount = 42,
            movieCount = 12,
            seriesCount = 8,
            isActive = true
        )
    }

    fun createSampleStreams(playlistId: Long): List<StreamEntity> {
        val list = mutableListOf<StreamEntity>()

        // 1. Top
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "aljazeera_en",
                name = "Al Jazeera English HD",
                streamUrl = "https://live-hls-web-aje.getaj.net/AJE/01.m3u8",
                logoUrl = "https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/Al_Jazeera_logo.svg/320px-Al_Jazeera_logo.svg.png",
                category = "Top",
                type = ChannelType.LIVE,
                epgChannelId = "aljazeera_en"
            )
        )
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "france24_en",
                name = "France 24 English",
                streamUrl = "https://static.france24.com/live/F24_EN_LO_HLS/live_tv.m3u8",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/France_24_logo.svg/320px-France_24_logo.svg.png",
                category = "Top",
                type = ChannelType.LIVE,
                epgChannelId = "france24_en"
            )
        )
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "top_nasa",
                name = "NASA TV Ultra HD",
                streamUrl = "https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/NASA_logo.svg/320px-NASA_logo.svg.png",
                category = "Top",
                type = ChannelType.LIVE,
                epgChannelId = "nasa_tv"
            )
        )

        // 2. Sports
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "bein_sports_1",
                name = "beIN Sports News HD",
                streamUrl = "https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7b/BeIN_Sports_logo.svg/320px-BeIN_Sports_logo.svg.png",
                category = "Sports",
                type = ChannelType.LIVE,
                epgChannelId = "bein_sports_1"
            )
        )
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "bein_sports_action",
                name = "beIN Sports Action Live",
                streamUrl = "https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8",
                logoUrl = "https://upload.wikimedia.org/wikipedia/en/thumb/f/f5/Red_Bull_TV_logo.svg/320px-Red_Bull_TV_logo.svg.png",
                category = "Sports",
                type = ChannelType.LIVE
            )
        )

        // 3. MBC
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "mbc_drama",
                name = "MBC Drama HD",
                streamUrl = "https://dwstream4-lh.akamaihd.net/i/dwarabic_0@412702/master.m3u8",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/MBC_Group_Logo.svg/320px-MBC_Group_Logo.svg.png",
                category = "MBC",
                type = ChannelType.LIVE,
                epgChannelId = "mbc_drama"
            )
        )
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "mbc_action",
                name = "MBC Action Live",
                streamUrl = "https://static.france24.com/live/F24_AR_LO_HLS/live_tv.m3u8",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/MBC_Group_Logo.svg/320px-MBC_Group_Logo.svg.png",
                category = "MBC",
                type = ChannelType.LIVE
            )
        )

        // 4. Cinema
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "cinema_action_1",
                name = "Action Cinema HD",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                logoUrl = "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400",
                category = "Cinema",
                type = ChannelType.LIVE
            )
        )
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "cinema_action_2",
                name = "Hollywood Premiere Cinema",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                logoUrl = "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400",
                category = "Cinema",
                type = ChannelType.LIVE
            )
        )

        // 5. STC
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "stc_sports_1",
                name = "STC Sports 1 HD",
                streamUrl = "https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8",
                logoUrl = "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400",
                category = "STC",
                type = ChannelType.LIVE
            )
        )

        // 6. beIN
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "bein_ent_1",
                name = "beIN Series Max HD",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
                logoUrl = "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=400",
                category = "beIN",
                type = ChannelType.LIVE
            )
        )

        // 7. Drama
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "drama_shows_1",
                name = "Global Drama Channel",
                streamUrl = "https://dwstream4-lh.akamaihd.net/i/dwarabic_0@412702/master.m3u8",
                logoUrl = "https://images.unsplash.com/photo-1578022761797-b8636ac1773c?w=400",
                category = "Drama",
                type = ChannelType.LIVE
            )
        )

        // 8. WatchIT
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "watchit_live_1",
                name = "WatchIT Originals Live",
                streamUrl = "https://static.france24.com/live/F24_AR_LO_HLS/live_tv.m3u8",
                logoUrl = "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=400",
                category = "WatchIT",
                type = ChannelType.LIVE
            )
        )

        // 9. Shahid
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "shahid_vip_1",
                name = "Shahid VIP Live Cinema",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                logoUrl = "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400",
                category = "Shahid",
                type = ChannelType.LIVE
            )
        )

        // 10. Netflix
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "netflix_vip_1",
                name = "Netflix VIP Premieres",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Netflix_2015_logo.svg/320px-Netflix_2015_logo.svg.png",
                category = "Netflix",
                type = ChannelType.LIVE
            )
        )

        // 11. News
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "dw_english",
                name = "DW English Live 24/7",
                streamUrl = "https://dwstream4-lh.akamaihd.net/i/dwarabic_0@412702/master.m3u8",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_logo.svg/320px-Deutsche_Welle_logo.svg.png",
                category = "News",
                type = ChannelType.LIVE,
                epgChannelId = "dw_english"
            )
        )
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "euronews_world",
                name = "Euronews World Live",
                streamUrl = "https://euronews-euronews-world-1-eu.rakuten.wurl.tv/playlist.m3u8",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Euronews_2016_logo.svg/320px-Euronews_2016_logo.svg.png",
                category = "News",
                type = ChannelType.LIVE
            )
        )

        // 12. Documentary
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "wild_earth_nature",
                name = "WildEarth Safari Live",
                streamUrl = "https://wildearth-samsungau.amagi.tv/playlist.m3u8",
                logoUrl = "https://wildearth.tv/wp-content/themes/wildearth/assets/images/logo.png",
                category = "Documentary",
                type = ChannelType.LIVE,
                epgChannelId = "wild_earth"
            )
        )

        // MOVIES CATEGORIES (VOD)
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "vod_big_buck",
                name = "Big Buck Bunny (4K Remaster)",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Big_buck_bunny_poster_big.jpg/320px-Big_buck_bunny_poster_big.jpg",
                category = "Animation",
                type = ChannelType.MOVIE,
                rating = "8.2",
                releaseDate = "2024",
                plot = "A giant rabbit with a heart of gold takes revenge on bullies in the forest with comedy and heart."
            )
        )
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "vod_tears_of_steel",
                name = "Tears of Steel (Sci-Fi 1080p)",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/Tears_of_Steel_poster.jpg/320px-Tears_of_Steel_poster.jpg",
                category = "SciFi",
                type = ChannelType.MOVIE,
                rating = "7.8",
                releaseDate = "2023",
                plot = "A dystopian future where warriors and scientists try to save the planet."
            )
        )
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "vod_sintel",
                name = "Sintel (Fantasy Adventure)",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Sintel_poster.jpg/320px-Sintel_poster.jpg",
                category = "Fantasy",
                type = ChannelType.MOVIE,
                rating = "8.4",
                releaseDate = "2022",
                plot = "A lonely young woman searches the dangerous wilderness for a baby dragon."
            )
        )
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "vod_elephants_dream",
                name = "Elephants Dream (Open Cinema)",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                logoUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Elephants_Dream_poster.jpg/320px-Elephants_Dream_poster.jpg",
                category = "Cinema",
                type = ChannelType.MOVIE,
                rating = "7.5",
                releaseDate = "2021",
                plot = "A surreal exploration of the human mind and technology."
            )
        )

        // SERIES
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "series_cosmos_e1",
                name = "Cosmos Discovery - S01E01",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                logoUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400",
                category = "Documentary",
                type = ChannelType.SERIES,
                seasonNumber = 1,
                episodeNumber = 1,
                seriesId = "Cosmos Discovery",
                rating = "9.1",
                plot = "Journey into deep space and the origin of stars."
            )
        )
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "series_cosmos_e2",
                name = "Cosmos Discovery - S01E02",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                logoUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400",
                category = "Documentary",
                type = ChannelType.SERIES,
                seasonNumber = 1,
                episodeNumber = 2,
                seriesId = "Cosmos Discovery",
                rating = "9.0",
                plot = "Black holes, event horizons, and gravity distortion."
            )
        )
        list.add(
            StreamEntity(
                playlistId = playlistId,
                streamId = "series_ocean_e1",
                name = "Ocean Abyss - S01E01",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                logoUrl = "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400",
                category = "Nature",
                type = ChannelType.SERIES,
                seasonNumber = 1,
                episodeNumber = 1,
                seriesId = "Ocean Abyss",
                rating = "8.9",
                plot = "Exploring the uncharted depths of the Mariana Trench."
            )
        )

        return list
    }

    fun createSampleEpg(): List<EpgProgramEntity> {
        val now = System.currentTimeMillis()
        val oneHour = 3600_000L
        val list = mutableListOf<EpgProgramEntity>()

        val channels = listOf(
            "aljazeera_en" to listOf("Main News Hour", "Inside Story", "The Listening Post", "Counting the Cost", "Earthrise"),
            "france24_en" to listOf("World News Live", "The Debate", "Focus Europe", "Eye on Social", "Culture Show"),
            "top_nasa" to listOf("ISS Expedition Live Stream", "Artemis Lunar Update", "Hubble Deep Field Insights", "Space Station Science"),
            "bein_sports_1" to listOf("Football Weekly Roundup", "Match of the Day", "Champions League Preview", "Highlights Reel"),
            "mbc_drama" to listOf("Prime Drama Premiere", "Late Night Theatre", "Celebrity Spotlight", "Series Showcase")
        )

        channels.forEach { (channelId, programs) ->
            var startTime = now - (oneHour / 2)
            programs.forEach { title ->
                val endTime = startTime + oneHour
                list.add(
                    EpgProgramEntity(
                        channelId = channelId,
                        title = title,
                        description = "Live broadcasting, exclusive reporting, and in-depth expert analysis.",
                        startEpoch = startTime,
                        endEpoch = endTime
                    )
                )
                startTime = endTime
            }
        }

        return list
    }
}
