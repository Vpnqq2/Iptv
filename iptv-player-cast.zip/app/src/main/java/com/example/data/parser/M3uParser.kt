package com.example.data.parser

import com.example.data.local.StreamEntity
import com.example.data.model.ChannelType
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.util.regex.Pattern

data class M3uParseResult(
    val streams: List<StreamEntity>,
    val epgUrl: String? = null
)

object M3uParser {

    private val TVG_ID_REGEX = Pattern.compile("tvg-id=\"([^\"]*)\"")
    private val TVG_NAME_REGEX = Pattern.compile("tvg-name=\"([^\"]*)\"")
    private val TVG_LOGO_REGEX = Pattern.compile("tvg-logo=\"([^\"]*)\"")
    private val GROUP_TITLE_REGEX = Pattern.compile("group-title=\"([^\"]*)\"")
    private val URL_TVG_REGEX = Pattern.compile("(?:url-tvg|x-tvg-url)=\"([^\"]*)\"", Pattern.CASE_INSENSITIVE)

    fun parse(inputStream: InputStream, playlistId: Long): List<StreamEntity> {
        return parseWithEpg(inputStream, playlistId).streams
    }

    private val VALID_PROTOCOLS = setOf("http", "https", "rtmp", "rtsp", "mms", "udp", "rtp")

    fun isValidStreamUrl(url: String): Boolean {
        val trimmed = url.trim()
        if (trimmed.length < 7) return false
        val colonIdx = trimmed.indexOf("://")
        if (colonIdx == -1) return false
        val scheme = trimmed.substring(0, colonIdx).lowercase()
        return scheme in VALID_PROTOCOLS
    }

    fun parseWithEpg(inputStream: InputStream, playlistId: Long): M3uParseResult {
        val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))
        val result = mutableListOf<StreamEntity>()
        val seenStreamKeys = HashSet<String>()
        var foundEpgUrl: String? = null

        var currentExtInf: String? = null
        var lineIndex = 0

        reader.forEachLine { line ->
            val trimmed = line.trim()
            if (trimmed.startsWith("#EXTM3U", ignoreCase = true)) {
                foundEpgUrl = extractAttribute(URL_TVG_REGEX, trimmed)
            } else if (trimmed.startsWith("#EXTINF:", ignoreCase = true)) {
                currentExtInf = trimmed
            } else if (!trimmed.startsWith("#") && trimmed.isNotBlank() && currentExtInf != null) {
                val streamUrl = trimmed
                if (isValidStreamUrl(streamUrl)) {
                    val stream = parseEntry(currentExtInf!!, streamUrl, playlistId, lineIndex++)
                    if (stream != null) {
                        // Prevent duplicate entries by checking unique URL or unique streamId+type
                        val streamKey = stream.streamUrl.trim()
                        if (seenStreamKeys.add(streamKey)) {
                            result.add(stream)
                        }
                    }
                }
                currentExtInf = null
            }
        }

        return M3uParseResult(result, foundEpgUrl)
    }

    private fun parseEntry(
        extInf: String,
        url: String,
        playlistId: Long,
        index: Int
    ): StreamEntity? {
        val trimmedUrl = url.trim()
        if (!isValidStreamUrl(trimmedUrl)) return null

        val tvgId = extractAttribute(TVG_ID_REGEX, extInf)?.ifBlank { null }
        val tvgName = extractAttribute(TVG_NAME_REGEX, extInf)?.ifBlank { null }
        val tvgLogo = extractAttribute(TVG_LOGO_REGEX, extInf)?.ifBlank { null }
        val rawGroupTitle = extractAttribute(GROUP_TITLE_REGEX, extInf) ?: "General"
        val groupTitle = com.example.util.CategorySanitizer.clean(rawGroupTitle).ifBlank { "General" }

        // The channel title is after the last comma in #EXTINF
        val commaIndex = extInf.lastIndexOf(',')
        val displayName = if (commaIndex != -1 && commaIndex < extInf.length - 1) {
            extInf.substring(commaIndex + 1).trim()
        } else {
            tvgName ?: "Channel ${index + 1}"
        }

        val finalName = displayName.ifBlank { tvgName ?: "Channel ${index + 1}" }
        val type = detectType(groupTitle, trimmedUrl, finalName)

        // Parse series/season/episode if applicable
        var seasonNum: Int? = null
        var epNum: Int? = null
        var seriesId: String? = null

        if (type == ChannelType.SERIES) {
            val seMatch = Regex("""[Ss](\d{1,2})[Ee](\d{1,2})""").find(finalName)
            if (seMatch != null) {
                seasonNum = seMatch.groupValues[1].toIntOrNull()
                epNum = seMatch.groupValues[2].toIntOrNull()
                seriesId = finalName.substring(0, seMatch.range.first).trim().ifBlank { null }
            }
        }

        val generatedStreamId = tvgId ?: "stream_${playlistId}_$index"

        return StreamEntity(
            playlistId = playlistId,
            streamId = generatedStreamId,
            name = finalName,
            streamUrl = trimmedUrl,
            logoUrl = tvgLogo,
            category = groupTitle,
            type = type,
            epgChannelId = tvgId,
            seasonNumber = seasonNum,
            episodeNumber = epNum,
            seriesId = seriesId
        )
    }

    private fun extractAttribute(pattern: Pattern, text: String): String? {
        val matcher = pattern.matcher(text)
        return if (matcher.find()) matcher.group(1)?.trim() else null
    }

    private fun detectType(category: String, url: String, name: String): ChannelType {
        val lowerCat = category.lowercase()
        val lowerUrl = url.lowercase()
        val lowerName = name.lowercase()

        // Series detection
        if (lowerCat.contains("series") || lowerCat.contains("مسلسلات") ||
            lowerUrl.contains("/series/") ||
            Regex("""[Ss]\d{1,2}[Ee]\d{1,2}""").containsMatchIn(name)
        ) {
            return ChannelType.SERIES
        }

        // Movies detection
        if (lowerCat.contains("movie") || lowerCat.contains("film") || lowerCat.contains("cinema") ||
            lowerCat.contains("vod") || lowerCat.contains("أفلام") ||
            lowerUrl.contains("/movie/") ||
            lowerUrl.endsWith(".mp4") || lowerUrl.endsWith(".mkv") || lowerUrl.endsWith(".avi")
        ) {
            return ChannelType.MOVIE
        }

        return ChannelType.LIVE
    }
}
