package com.example.cast

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Minimal LAN HTTP relay that runs inside the app.
 *
 * Why it exists: IPTV URLs embed the account username/password. A TV or Chromecast has to fetch
 * the media itself, so instead of giving it the real URL we give it http://<phone-ip>:<port>/r/<random-id>.
 * The relay looks the id up and fetches the real URL from the phone, adding CORS headers (required
 * by the Cast web receiver for HLS) and rewriting HLS playlists so segments also go through the relay.
 *
 * Safety properties:
 *  - only ids registered by the app are served (128-bit random, unguessable);
 *  - only clients from private/loopback/link-local addresses are accepted;
 *  - upstream URLs, upstream error bodies and credentials are never written to the client or to logs.
 *
 * Trade-off: media bytes flow through the phone while casting (Wi-Fi + battery).
 */
class CastRelayServer(
    private val client: OkHttpClient = defaultClient(),
    private val userAgent: String = "AndroidXMedia3/1.5.1"
) {
    // LRU map: live HLS registers new segment ids continuously; the playlist id is touched on every
    // reload so it stays, old segment ids age out.
    private val routes: MutableMap<String, String> = java.util.Collections.synchronizedMap(
        object : LinkedHashMap<String, String>(64, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > MAX_ROUTES
        }
    )
    private val random = SecureRandom()
    private var server: ServerSocket? = null
    private var pool: ExecutorService? = null

    val port: Int get() = server?.localPort ?: -1
    val isRunning: Boolean get() = server?.isClosed == false

    @Synchronized
    fun start(): Int {
        server?.let { if (!it.isClosed) return it.localPort }
        val ss = ServerSocket(0, 50)
        val ex = Executors.newCachedThreadPool()
        server = ss
        pool = ex
        ex.execute { acceptLoop(ss, ex) }
        return ss.localPort
    }

    @Synchronized
    fun stop() {
        try { server?.close() } catch (_: IOException) {}
        server = null
        pool?.shutdownNow()
        pool = null
        routes.clear()
    }

    /** Forget every registered stream (used when a new cast session / media starts). */
    fun clearRoutes() = routes.clear()

    fun register(upstreamUrl: String): String {
        val bytes = ByteArray(16).also { random.nextBytes(it) }
        val id = bytes.joinToString("") { "%02x".format(it) }
        routes[id] = upstreamUrl
        return id
    }

    /** Builds the URL a device on the LAN should use for [upstreamUrl]. */
    fun urlFor(host: String, upstreamUrl: String): String {
        val id = register(upstreamUrl)
        return "http://$host:$port/r/$id${suffixFor(upstreamUrl)}"
    }

    private fun suffixFor(url: String): String {
        val ext = CastUrlPolicy.extensionOf(url)
        return if (ext in KNOWN_EXT) ".$ext" else ""
    }

    private fun acceptLoop(ss: ServerSocket, ex: ExecutorService) {
        while (!ss.isClosed) {
            val s = try { ss.accept() } catch (_: IOException) { return }
            try {
                ex.execute { handle(s) }
            } catch (_: Exception) { closeQuietly(s) }
        }
    }

    private fun handle(sock: Socket) {
        try {
            val addr = sock.inetAddress
            if (!(addr.isSiteLocalAddress || addr.isLoopbackAddress || addr.isLinkLocalAddress)) return
            sock.soTimeout = 20_000
            val input = BufferedInputStream(sock.getInputStream())
            val out = BufferedOutputStream(sock.getOutputStream())
            val requestLine = readLine(input) ?: return
            val parts = requestLine.split(' ')
            if (parts.size < 2) { writeSimple(out, 400, "Bad Request"); return }
            val method = parts[0].uppercase()
            val target = parts[1]
            val headers = HashMap<String, String>()
            while (true) {
                val l = readLine(input) ?: break
                if (l.isEmpty()) break
                val i = l.indexOf(':')
                if (i > 0) headers[l.substring(0, i).trim().lowercase()] = l.substring(i + 1).trim()
            }
            when (method) {
                "OPTIONS" -> { writeSimple(out, 204, "No Content"); return }
                "GET", "HEAD" -> {}
                else -> { writeSimple(out, 405, "Method Not Allowed"); return }
            }
            val id = parseId(target)
            val upstream = id?.let { routes[it] }
            if (upstream == null) { writeSimple(out, 404, "Not Found"); return }
            sock.soTimeout = 0 // live streams may be silent for long periods
            serve(out, method, upstream, headers["range"])
        } catch (_: IOException) {
            // client went away; nothing to do
        } catch (_: Exception) {
        } finally {
            closeQuietly(sock)
        }
    }

    private fun serve(out: OutputStream, method: String, upstream: String, range: String?) {
        val req = try {
            Request.Builder().url(upstream).method(method, null)
                .header("User-Agent", userAgent)
                .apply { if (range != null) header("Range", range) }
                .build()
        } catch (_: Exception) { writeSimple(out, 502, "Bad Gateway"); return }

        val resp = try { client.newCall(req).execute() } catch (_: Exception) {
            writeSimple(out, 502, "Bad Gateway"); return
        }
        resp.use { r ->
            if (r.code !in 200..299) {
                // pass the status through (401/403/404 ...) but never the body or URL
                writeSimple(out, if (r.code in 400..499) r.code else 502, reason(r.code)); return
            }
            val finalUrl = r.request.url.toString()
            val ct = r.header("Content-Type").orEmpty()
            val playlistByHeader = ct.contains("mpegurl", ignoreCase = true)
            val playlistByUrl = CastUrlPolicy.extensionOf(finalUrl) in setOf("m3u8", "m3u")
            if (method == "GET" && (playlistByHeader || playlistByUrl)) {
                val body = r.body?.source()?.let { src ->
                    src.request(MAX_PLAYLIST_BYTES + 1)
                    src.buffer.readByteArray(minOf(src.buffer.size, MAX_PLAYLIST_BYTES.toLong()))
                } ?: ByteArray(0)
                val text = String(body, Charsets.UTF_8)
                val bytes = if (M3u8Rewriter.looksLikePlaylist(text)) {
                    val host = currentHost
                    M3u8Rewriter.rewrite(text, finalUrl) { abs -> "http://$host:$port/r/${register(abs)}${suffixFor(abs)}" }
                        .toByteArray(Charsets.UTF_8)
                } else body
                writeHead(out, 200, "OK", linkedMapOf(
                    "Content-Type" to "application/vnd.apple.mpegurl",
                    "Content-Length" to bytes.size.toString(),
                    "Cache-Control" to "no-cache"
                ))
                out.write(bytes); out.flush()
                return
            }
            val h = linkedMapOf<String, String>()
            h["Content-Type"] = ct.ifBlank { "application/octet-stream" }
            r.header("Content-Length")?.let { h["Content-Length"] = it }
            r.header("Content-Range")?.let { h["Content-Range"] = it }
            h["Accept-Ranges"] = r.header("Accept-Ranges") ?: "none"
            writeHead(out, r.code, reason(r.code), h)
            if (method == "HEAD") { out.flush(); return }
            val buf = ByteArray(64 * 1024)
            val src: InputStream = r.body?.byteStream() ?: return
            while (true) {
                val n = src.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                out.flush()
            }
        }
    }

    /** Host (LAN IP) used when rewriting playlists; set by the manager before registering streams. */
    @Volatile var currentHost: String = "127.0.0.1"

    private fun parseId(target: String): String? {
        val path = target.substringBefore('?')
        if (!path.startsWith("/r/")) return null
        val seg = path.removePrefix("/r/").substringBefore('/')
        val id = seg.substringBefore('.')
        return if (id.length == 32 && id.all { it in "0123456789abcdef" }) id else null
    }

    private fun writeSimple(out: OutputStream, code: Int, reason: String) {
        writeHead(out, code, reason, linkedMapOf("Content-Length" to "0"))
        out.flush()
    }

    private fun writeHead(out: OutputStream, code: Int, reason: String, headers: Map<String, String>) {
        val sb = StringBuilder("HTTP/1.1 $code $reason\r\n")
        headers.forEach { (k, v) -> sb.append(k).append(": ").append(v).append("\r\n") }
        sb.append("Access-Control-Allow-Origin: *\r\n")
        sb.append("Access-Control-Allow-Methods: GET, HEAD, OPTIONS\r\n")
        sb.append("Access-Control-Allow-Headers: Range, Content-Type\r\n")
        sb.append("Access-Control-Expose-Headers: Content-Length, Content-Range, Accept-Ranges\r\n")
        sb.append("Connection: close\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
    }

    private fun reason(code: Int) = when (code) {
        200 -> "OK"; 206 -> "Partial Content"; 401 -> "Unauthorized"; 403 -> "Forbidden"
        404 -> "Not Found"; else -> "Error"
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = input.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
        }
        return null
    }

    private fun closeQuietly(s: Socket) { try { s.close() } catch (_: IOException) {} }

    companion object {
        private const val MAX_ROUTES = 5000
        private const val MAX_PLAYLIST_BYTES = 5 * 1024 * 1024
        private val KNOWN_EXT = setOf("m3u8", "ts", "mp4", "m4s", "mkv", "webm", "aac", "mp3", "vtt", "key")

        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}
