package com.example.cast

import android.content.Context
import android.net.Uri
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.MediaSeekOptions
import com.google.android.gms.cast.MediaStatus
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import com.google.android.gms.cast.framework.media.RemoteMediaClient
import com.google.android.gms.common.images.WebImage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors

/**
 * Google Cast (Chromecast, Google TV, Android TV with built-in Cast, many smart TVs) via the official
 * Cast Application Framework sender SDK. Discovery uses androidx.mediarouter; the session is owned by
 * the Cast framework. Android TV apps do NOT receive Cast unless the TV exposes a Cast receiver
 * (Google TV / Chromecast built-in does; a plain Android TV box running only this app does not).
 */
class GoogleCastController(private val context: Context) {

    private val _devices = MutableStateFlow<List<CastDeviceInfo>>(emptyList())
    val devices: StateFlow<List<CastDeviceInfo>> = _devices.asStateFlow()

    private val _state = MutableStateFlow<CastSessionState>(CastSessionState.Idle)
    val state: StateFlow<CastSessionState> = _state.asStateFlow()

    private val _status = MutableStateFlow(RemotePlaybackStatus())
    val status: StateFlow<RemotePlaybackStatus> = _status.asStateFlow()

    private val _available = MutableStateFlow<Boolean?>(null) // null = still initializing
    val available: StateFlow<Boolean?> = _available.asStateFlow()

    private var castContext: CastContext? = null
    private var router: MediaRouter? = null
    private var selector: MediaRouteSelector? = null
    private var discovering = false
    private var pendingName: String = ""

    private val routeCallback = object : MediaRouter.Callback() {
        override fun onRouteAdded(r: MediaRouter, route: MediaRouter.RouteInfo) = refreshRoutes()
        override fun onRouteRemoved(r: MediaRouter, route: MediaRouter.RouteInfo) = refreshRoutes()
        override fun onRouteChanged(r: MediaRouter, route: MediaRouter.RouteInfo) = refreshRoutes()
    }

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarting(s: CastSession) { _state.value = CastSessionState.Connecting(pendingName.ifBlank { name(s) }) }
        override fun onSessionStarted(s: CastSession, id: String) = connected(s)
        override fun onSessionStartFailed(s: CastSession, error: Int) { _state.value = CastSessionState.Failed(CastError.CONNECTION_FAILED) }
        override fun onSessionEnding(s: CastSession) {}
        override fun onSessionEnded(s: CastSession, error: Int) {
            detachRemote()
            _state.value = if (error == 0) CastSessionState.Idle else CastSessionState.Failed(CastError.DEVICE_LOST)
        }
        override fun onSessionResuming(s: CastSession, id: String) { _state.value = CastSessionState.Reconnecting(name(s)) }
        override fun onSessionResumed(s: CastSession, wasSuspended: Boolean) = connected(s)
        override fun onSessionResumeFailed(s: CastSession, error: Int) { _state.value = CastSessionState.Failed(CastError.DEVICE_LOST) }
        override fun onSessionSuspended(s: CastSession, reason: Int) { _state.value = CastSessionState.Reconnecting(name(s)) }
    }

    private val remoteCallback = object : RemoteMediaClient.Callback() {
        override fun onStatusUpdated() = publishStatus()
        override fun onMetadataUpdated() = publishStatus()
    }

    fun init() {
        if (castContext != null) return
        try {
            CastContext.getSharedInstance(context, Executors.newSingleThreadExecutor())
                .addOnSuccessListener { cc ->
                    castContext = cc
                    router = MediaRouter.getInstance(context)
                    selector = cc.mergedSelector
                    cc.sessionManager.addSessionManagerListener(sessionListener, CastSession::class.java)
                    cc.sessionManager.currentCastSession?.let { if (it.isConnected) connected(it) }
                    _available.value = true
                    if (discovering) startDiscovery()
                }
                .addOnFailureListener { _available.value = false }
        } catch (_: Exception) {
            _available.value = false // Play services missing/outdated
        }
    }

    // ---- discovery ----

    fun startDiscovery() {
        discovering = true
        val r = router ?: return
        val sel = selector ?: return
        r.addCallback(sel, routeCallback, MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY or MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN)
        refreshRoutes()
    }

    fun stopDiscovery() {
        discovering = false
        router?.removeCallback(routeCallback)
    }

    private fun refreshRoutes() {
        val r = router ?: return
        val sel = selector ?: return
        _devices.value = r.routes
            .filter { !it.isDefault && it.matchesSelector(sel) && it.isEnabled }
            .map { CastDeviceInfo(it.id, it.name, CastProtocol.GOOGLE_CAST) }
    }

    // ---- session ----

    fun connect(deviceId: String) {
        val r = router ?: run { _state.value = CastSessionState.Failed(CastError.NO_PLAY_SERVICES); return }
        val route = r.routes.firstOrNull { it.id == deviceId } ?: run { _state.value = CastSessionState.Failed(CastError.DEVICE_LOST); return }
        pendingName = route.name
        _state.value = CastSessionState.Connecting(route.name)
        r.selectRoute(route) // CAF starts the session when its route is selected
    }

    fun disconnect() {
        castContext?.sessionManager?.endCurrentSession(true)
        router?.unselect(MediaRouter.UNSELECT_REASON_STOPPED)
        detachRemote()
        _state.value = CastSessionState.Idle
    }

    private fun connected(s: CastSession) {
        _state.value = CastSessionState.Connected(name(s), CastProtocol.GOOGLE_CAST)
        s.remoteMediaClient?.let { it.unregisterCallback(remoteCallback); it.registerCallback(remoteCallback) }
        publishStatus()
    }

    private fun detachRemote() {
        castContext?.sessionManager?.currentCastSession?.remoteMediaClient?.unregisterCallback(remoteCallback)
        _status.value = RemotePlaybackStatus()
    }

    private fun name(s: CastSession) = s.castDevice?.friendlyName ?: pendingName.ifBlank { "Chromecast" }

    private fun client(): RemoteMediaClient? = castContext?.sessionManager?.currentCastSession?.remoteMediaClient

    // ---- playback ----

    /**
     * Loads [url] on the receiver. [onResult] gets null on success or a [CastError].
     * The URL must already be safe for the TV (relay URL if the original carried credentials).
     */
    fun load(url: String, title: String, logo: String?, mime: String, isLive: Boolean, startMs: Long, onResult: (CastError?) -> Unit) {
        val c = client() ?: run { onResult(CastError.DEVICE_LOST); return }
        val meta = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(MediaMetadata.KEY_TITLE, title)
            logo?.takeIf { it.startsWith("http") }?.let { addImage(WebImage(Uri.parse(it))) }
        }
        val info = MediaInfo.Builder(url)
            .setStreamType(if (isLive) MediaInfo.STREAM_TYPE_LIVE else MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType(mime)
            .setMetadata(meta)
            .build()
        val req = MediaLoadRequestData.Builder()
            .setMediaInfo(info)
            .setAutoplay(true)
            .setCurrentTime(if (isLive) 0L else startMs)
            .build()
        c.load(req).setResultCallback { res ->
            onResult(if (res.status.isSuccess) null else CastError.UNSUPPORTED_FORMAT)
        }
    }

    fun play() { client()?.play() }
    fun pause() { client()?.pause() }
    fun stopMedia() { client()?.stop() }
    fun seek(ms: Long) { client()?.seek(MediaSeekOptions.Builder().setPosition(ms).build()) }

    fun setVolume(v: Float) {
        try { castContext?.sessionManager?.currentCastSession?.volume = v.toDouble().coerceIn(0.0, 1.0) } catch (_: Exception) {}
        _status.value = _status.value.copy(volume = v)
    }

    fun position(): Long = client()?.approximateStreamPosition ?: 0L

    private fun publishStatus() {
        val c = client() ?: return
        val ms = c.mediaStatus
        val ps = ms?.playerState ?: MediaStatus.PLAYER_STATE_UNKNOWN
        val failed = ps == MediaStatus.PLAYER_STATE_IDLE && ms?.idleReason == MediaStatus.IDLE_REASON_ERROR
        _status.value = RemotePlaybackStatus(
            isPlaying = ps == MediaStatus.PLAYER_STATE_PLAYING,
            isBuffering = ps == MediaStatus.PLAYER_STATE_BUFFERING || ps == MediaStatus.PLAYER_STATE_LOADING,
            hasMedia = ms != null && ps != MediaStatus.PLAYER_STATE_IDLE,
            volume = castContext?.sessionManager?.currentCastSession?.volume?.toFloat() ?: _status.value.volume,
            canSeek = ms?.isMediaCommandSupported(MediaStatus.COMMAND_SEEK) == true && c.isLiveStream.not(),
            positionMs = c.approximateStreamPosition,
            durationMs = c.streamDuration.coerceAtLeast(0L),
            error = if (failed) CastError.UNSUPPORTED_FORMAT else null
        )
    }
}
