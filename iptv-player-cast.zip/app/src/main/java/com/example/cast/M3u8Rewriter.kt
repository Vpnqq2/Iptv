package com.example.cast

import java.net.URI

/**
 * Rewrites an HLS playlist so every referenced URL (segments, variant playlists, keys, init maps)
 * points to the local relay. [register] receives the absolute upstream URL and returns the
 * relay URL to put in the playlist; the receiver therefore never sees upstream URLs/credentials.
 */
object M3u8Rewriter {
    private val uriAttr = Regex("URI=\"([^\"]*)\"")

    fun looksLikePlaylist(body: String): Boolean = body.trimStart().startsWith("#EXTM3U")

    fun rewrite(body: String, baseUrl: String, register: (String) -> String): String {
        val base = try { URI(baseUrl) } catch (_: Exception) { null }
        fun abs(ref: String): String? {
            val r = ref.trim()
            if (r.isEmpty()) return null
            return try {
                if (base != null) base.resolve(r).toString() else r
            } catch (_: Exception) { null }
        }
        return body.lineSequence().joinToString("\n") { raw ->
            val line = raw.trimEnd('\r')
            when {
                line.isBlank() -> line
                line.startsWith("#") -> uriAttr.replace(line) { m ->
                    val a = abs(m.groupValues[1])
                    if (a == null || a.startsWith("data:")) m.value else "URI=\"${register(a)}\""
                }
                else -> abs(line)?.let(register) ?: line
            }
        }
    }
}
