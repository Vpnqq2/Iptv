package com.example.cast

import com.example.data.model.ChannelType
import java.net.URI

/**
 * Pure helpers (no Android dependencies) that decide how a stream URL may be handed to a TV.
 *
 * Key rule: Xtream-style URLs carry the IPTV username/password inside the URL itself
 * (/live/USER/PASS/ID.ts). Those URLs must never be logged, shown in the UI, or given to
 * a receiver unless unavoidable. When [hasCredentials] is true the cast layer serves the
 * stream through the phone's local relay so the TV only ever sees an opaque URL.
 */
object CastUrlPolicy {

    private val xtreamPath = Regex("(/(?:live|movie|series|timeshift)/)([^/?#]+)/([^/?#]+)/")
    private val sensitiveQuery = Regex("([?&](?:username|password|user|pass|pwd|token|key)=)[^&#]*", RegexOption.IGNORE_CASE)
    private val userInfo = Regex("(://)[^/@?#]+@")

    /** Returns [url] with every credential-looking part replaced by ***. Safe for logs/UI. */
    fun redact(url: String): String =
        url.replace(xtreamPath, "$1***/***/")
            .replace(sensitiveQuery, "$1***")
            .replace(userInfo, "$1***@")

    fun hasCredentials(url: String): Boolean = redact(url) != url

    /** Loopback / unresolved-name hosts that another device on the LAN cannot reach. */
    fun isLoopbackHost(url: String): Boolean {
        val host = hostOf(url)?.lowercase() ?: return false
        return host == "localhost" || host == "::1" || host == "[::1]" || host.startsWith("127.") || host == "0.0.0.0"
    }

    fun isHttp(url: String): Boolean {
        val l = url.trim().lowercase()
        return l.startsWith("http://") || l.startsWith("https://")
    }

    fun hostOf(url: String): String? = try { URI(url.trim()).host } catch (_: Exception) { null }

    /** Lower-cased file extension of the URL path (no query), or "". */
    fun extensionOf(url: String): String {
        val path = try { URI(url.trim()).path ?: "" } catch (_: Exception) { url.substringBefore('?').substringBefore('#') }
        val name = path.substringAfterLast('/')
        return if (name.contains('.')) name.substringAfterLast('.').lowercase() else ""
    }

    /**
     * Xtream live streams default to raw MPEG-TS (".ts"). Chromecast and most TVs cannot play a
     * raw TS over progressive HTTP, but the same server exposes HLS at the same path with ".m3u8".
     */
    fun toCastableUrl(url: String, type: ChannelType): String {
        if (type == ChannelType.LIVE && extensionOf(url) == "ts" && xtreamPath.containsMatchIn(url)) {
            val q = url.indexOf('?')
            val base = if (q >= 0) url.substring(0, q) else url
            val tail = if (q >= 0) url.substring(q) else ""
            return base.removeSuffix(".ts") + ".m3u8" + tail
        }
        return url
    }

    fun mimeType(url: String, type: ChannelType): String = when (extensionOf(url)) {
        "m3u8", "m3u" -> "application/x-mpegURL"
        "mpd" -> "application/dash+xml"
        "mp4", "m4v" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "ts" -> "video/mp2t"
        "avi" -> "video/x-msvideo"
        "mov" -> "video/quicktime"
        else -> if (type == ChannelType.LIVE) "application/x-mpegURL" else "video/mp4"
    }

    fun isHls(mime: String): Boolean = mime.equals("application/x-mpegURL", true) ||
        mime.equals("application/vnd.apple.mpegurl", true)
}
