package com.example.cast

enum class CastProtocol { GOOGLE_CAST, DLNA }

data class CastDeviceInfo(
    val id: String,
    val name: String,
    val protocol: CastProtocol
)

/** Reasons a cast attempt can fail; the UI maps each one to a localized message. */
enum class CastError {
    NO_PLAY_SERVICES,
    NO_WIFI,
    CONNECTION_FAILED,
    DEVICE_LOST,
    AUTH_REQUIRED,
    NOT_FOUND,
    UNREACHABLE,
    TLS,
    UNSUPPORTED_FORMAT,
    RELAY_FAILED,
    INVALID_URL
}

sealed interface CastSessionState {
    data object Idle : CastSessionState
    data class Connecting(val deviceName: String) : CastSessionState
    data class Connected(val deviceName: String, val protocol: CastProtocol) : CastSessionState
    data class Reconnecting(val deviceName: String) : CastSessionState
    data class Failed(val error: CastError) : CastSessionState
}

data class RemotePlaybackStatus(
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val hasMedia: Boolean = false,
    val volume: Float = 1f,
    val canSeek: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val error: CastError? = null
)
