package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Unified Cinematic IPTV Palette
val DarkBg = Color(0xFF0C0E14)
val DarkSurface = Color(0xFF141720)
val DarkSurfaceVariant = Color(0xFF1E2330)
val DarkCard = Color(0xFF181C26)
val DarkCardBorder = Color(0xFF282F40)

val PrimaryBlue = Color(0xFF0EA5E9)
val PrimaryBlueGlow = Color(0xFF38BDF8)
val AccentCyan = Color(0xFF06B6D4)
val AccentEmerald = Color(0xFF10B981)
val AccentGold = Color(0xFFFBBF24)
val AccentRed = Color(0xFFEF4444)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val LiveRed = Color(0xFFEF4444)
val FavoriteGold = Color(0xFFF59E0B)
val OverlayBlack = Color(0xCC000000)
val OverlayGradient = Color(0x99000000)
