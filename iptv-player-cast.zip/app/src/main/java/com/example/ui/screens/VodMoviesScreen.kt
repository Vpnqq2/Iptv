package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategorySummary
import com.example.data.model.StreamItem
import com.example.ui.components.CategoryGridCard
import com.example.ui.components.MoviePosterCard
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun VodMoviesScreen(
    movies: List<StreamItem>,
    categories: List<CategorySummary>,
    strings: AppStrings.Strings,
    onPlayMovie: (StreamItem) -> Unit,
    onToggleFavorite: (StreamItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var categorySearchQuery by remember { mutableStateOf("") }
    var movieSearchQuery by remember { mutableStateOf("") }

    BackHandler(enabled = selectedCategory != null) {
        selectedCategory = null
        movieSearchQuery = ""
    }

    AnimatedContent(
        targetState = selectedCategory,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "VodCategoryTransition",
        modifier = modifier.fillMaxSize()
    ) { currentCat ->
        if (currentCat == null) {
            // VIEW 1: Categories Grid
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBg)
            ) {
                // Search in Categories
                OutlinedTextField(
                    value = categorySearchQuery,
                    onValueChange = { categorySearchQuery = it },
                    placeholder = { Text(strings.searchCategories, color = TextMuted, fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(20.dp))
                    },
                    trailingIcon = {
                        if (categorySearchQuery.isNotBlank()) {
                            IconButton(onClick = { categorySearchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedBorderColor = DarkSurfaceVariant,
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .height(48.dp)
                )

                val filteredCategories = remember(categories, categorySearchQuery) {
                    if (categorySearchQuery.isBlank()) categories
                    else categories.filter { it.name.contains(categorySearchQuery, ignoreCase = true) }
                }

                if (categories.isEmpty() && movies.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strings.noChannelsFound,
                            color = TextMuted,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        if (categorySearchQuery.isBlank()) {
                            item {
                                CategoryGridCard(
                                    name = strings.allCategories,
                                    count = movies.size,
                                    countLabel = strings.moviesCount,
                                    icon = Icons.Default.VideoLibrary,
                                    accentColor = AccentGold,
                                    onClick = { selectedCategory = "ALL_MOVIES" }
                                )
                            }
                        }

                        items(filteredCategories, key = { it.name }) { cat ->
                            CategoryGridCard(
                                name = cat.name,
                                count = cat.count,
                                countLabel = strings.moviesCount,
                                icon = Icons.Default.Movie,
                                accentColor = AccentCyan,
                                onClick = { selectedCategory = cat.name }
                            )
                        }
                    }
                }
            }
        } else {
            // VIEW 2: Inside Category - Movie Posters Grid
            val categoryMovies = remember(movies, currentCat, movieSearchQuery) {
                val list = if (currentCat == "ALL_MOVIES") movies
                else movies.filter { it.category.equals(currentCat, ignoreCase = true) }

                if (movieSearchQuery.isBlank()) list
                else list.filter { it.name.contains(movieSearchQuery, ignoreCase = true) }
            }

            val categoryDisplayName = if (currentCat == "ALL_MOVIES") strings.allCategories else currentCat

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBg)
            ) {
                Surface(
                    color = DarkSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = {
                                selectedCategory = null
                                movieSearchQuery = ""
                            }) {
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = TextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = categoryDisplayName,
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${categoryMovies.size} ${strings.moviesCount}",
                                    color = AccentCyan,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        OutlinedTextField(
                            value = movieSearchQuery,
                            onValueChange = { movieSearchQuery = it },
                            placeholder = { Text(strings.searchHint, color = TextMuted, fontSize = 12.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
                            },
                            trailingIcon = {
                                if (movieSearchQuery.isNotBlank()) {
                                    IconButton(onClick = { movieSearchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PrimaryBlue,
                                unfocusedBorderColor = DarkSurfaceVariant,
                                focusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f),
                                unfocusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f),
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                                .height(46.dp)
                        )
                    }
                }

                if (categoryMovies.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strings.noChannelsFound,
                            color = TextMuted,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 145.dp),
                        contentPadding = PaddingValues(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(categoryMovies, key = { it.id }) { movie ->
                            MoviePosterCard(
                                stream = movie,
                                onPlay = { onPlayMovie(movie) },
                                onToggleFavorite = { onToggleFavorite(movie) }
                            )
                        }
                    }
                }
            }
        }
    }
}
