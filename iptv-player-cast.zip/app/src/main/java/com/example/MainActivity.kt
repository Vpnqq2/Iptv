package com.example

import android.app.PictureInPictureParams
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.cast.CastManager
import com.example.ui.AppStartupState
import com.example.ui.IptvMainApp
import com.example.ui.MainViewModel
import com.example.ui.i18n.AppStrings
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.DarkBg
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        CastManager.init(applicationContext)
        setContent {
            MyApplicationTheme {
                val startupState by viewModel.startupState.collectAsStateWithLifecycle()
                val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
                val strings = AppStrings.get(currentLanguage)

                AnimatedContent(
                    targetState = startupState,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "StartupNav",
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DarkBg)
                ) { state ->
                    when (state) {
                        AppStartupState.SPLASH -> SplashScreen(
                            strings = strings,
                            onSplashFinished = { viewModel.onSplashFinished() }
                        )

                        AppStartupState.WELCOME -> WelcomeScreen(
                            strings = strings,
                            currentLanguage = currentLanguage,
                            onSelectLanguage = { viewModel.setLanguage(it) },
                            onConnectXtream = {
                                viewModel.completeWelcome(openAddXtream = true)
                            },
                            onImportM3u = {
                                viewModel.completeWelcome(openAddM3u = true)
                            },
                            onSkip = {
                                viewModel.completeWelcome()
                            }
                        )

                        AppStartupState.MAIN_APP -> IptvMainApp(viewModel = viewModel)
                    }
                }
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (viewModel.currentPlayingStream.value != null && !CastManager.isCasting && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (_: Exception) { }
        }
    }
}
